package day06;

public class Circle extends Shape{

}

package day06;

public class Novice {
	String name;
	int hp;

	void punch() {
		System.out.printf("%s(HP: %d)의 펀치!\n", name, hp);
	}
	
	// 기존 Novice 클래스에 움직임 기능을 부여
	// 이를 위해 필드 speed와 메소드 move()를 다음과 같이 추가
	// 자식들도 그대로 영향을 미치게 됨
}

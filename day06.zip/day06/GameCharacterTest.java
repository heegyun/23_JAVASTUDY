package day06;

public class GameCharacterTest {

	public static void main(String[] args) {
//		 Wizard wizard = new Wizard(); // 객체 생성
//	        wizard.name = "간달프";
//	        wizard.hp = 100;
//	        wizard.mp = 80;
//	        wizard.punch();
//	        wizard.fireball();
		Knight knight = new Knight();
		knight.name = "킹아서";
		knight.hp = 150;
		knight.stamina = 70;
		knight.punch();
		knight.slash();
	}

}


package day06;

public class Shape {
	  String name;
}

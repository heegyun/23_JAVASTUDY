package day06;

public class Square extends Shape{

}

package day06;

public class Triangle extends Shape{

}

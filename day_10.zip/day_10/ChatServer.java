package day_10;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

class ClientInfo {
    private Socket c;
    private String ip;
    private BufferedWriter bw;

    // 생성자..
    public ClientInfo(Socket c) {
        this.c = c;
        //소켓을 연결한 클라이언트의 IP정보를 저장한다.
        ip = c.getInetAddress().getHostAddress();

        //클라이언트에 문자열을 전송하기 위한 출력 스트림을 생성한다.
        try {
            bw = new BufferedWriter(new OutputStreamWriter(c.getOutputStream()));
        } catch (Exception e) {
        }
    }

    // 인자로 받은 문자열 출력 하는 메소드...
    public boolean write(String str) {
        //인자로 받은 문자열을 출력 스트림을 사용한 전송한다.
        try {
            bw.write(str + "\n");
            bw.flush();
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    // ip 반환 메소드
    public String getIp() {
        return ip;
    }
}// ClientInfo------------


class ChatThread implements Runnable {
    private Socket c = null;
    private BufferedReader br = null;
    private Vector v = null;

    // 생성자...
    public ChatThread(Socket c, Vector v) {
        this.c = c;
        this.v = v;

        //클라이언트로부터 전송된 내용을 읽어오기 위한 입력 스트림을 생성한다.
        try {
            br = new BufferedReader(new InputStreamReader(c.getInputStream()));
        }catch(Exception e) {}
    }

    public void run() {
        while(true) {
            String str=null;
            try {
                //클라이언트로 부터 문자열을 읽어온다.
                str = br.readLine();
            }catch(Exception e) {
                break;
            }

            for(int i=0; i<v.size(); i++) {
                //읽어온 문자열을 벡터객체에 저장된 각 클라이언트에 전송한다.
                ClientInfo ci = (ClientInfo)v.get(i);
                ci.write(str);
            }
        }

        try {
            //예외가 발생하여 while 루프가 종료되면 스트림과 소켓을 닫는다.
            br.close();
            c.close();
        }catch(Exception e) {}
    }
}//ChatThread-------------------------------------------

public class ChatServer {

    public static void main(String[] args) throws IOException {

        System.out.println("자바 사관학교 커뮤니티 채팅 서버 v1.0");

        ServerSocket ss= null;
        Vector v = null;

        try {
            //9000번 포트를 사용하는 서버 소켓을 생성한다.
            ss = new ServerSocket(9000);
            v = new Vector(10);

            while(true) {
                //클라이언트로부터 접속 요청이 발생하면 서버와 클라이언트 사이에
                //새로운 소켓을 생성한다.
                Socket c = ss.accept();

                //클라이언트의 정보를 저장하는 ClientInfo 클래스를 생성하고 벡터
                //객체에 저장한다.
                ClientInfo ci = new ClientInfo(c);
                v.add(ci);

                //각 소켓에 대한 작업을 수행할 쓰레드를 생성한다.
                ChatThread ct = new ChatThread(c, v);
                Thread t = new Thread(ct);
                t.start();

                System.out.println(ci.getIp()+"가 접속했습니다.");
            }
        }catch(Exception e) {
                ss.close();
                System.exit(0);

        }
    }
}//////////////////////////////////////////////////////////////////////

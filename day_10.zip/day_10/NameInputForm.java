package day_10;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NameInputForm extends JDialog  implements ActionListener {

    JTextField jtf_name ;
    JPanel jPanel;
    JButton jButton;

    ChatClient client;

    public NameInputForm(ChatClient client){

        // 다이얼로그 화면 구성하기
        setTitle("대화명(닉네임)을 입력하세요");
        setBounds(100,100,250,70);

        jtf_name = new JTextField(10);
        jPanel = new JPanel();
        jButton = new JButton("입력");

        //////////////////////////////////////
        jButton.addActionListener(this);
        /////////////////////////////////////
        jPanel.add(jtf_name);
        jPanel.add(jButton);

        //this.add(jPanel);
        getContentPane().add(jPanel);

        this.client = client;

        //setVisible(true);

    }// 생성자.........


    @Override
    public void actionPerformed(ActionEvent e) {

        Object obj = e.getSource();

        if(obj == jButton){
            String str = jtf_name.getText().toString();
            client.setName(str);
            setVisible(false);
            show(false);
        }
    }
    /////////////////////////

}

package day_10;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class ServerInputForm extends JDialog implements ActionListener {
    private JLabel ipl;
    private JLabel portl;
    private JTextField iptf;
    private JTextField porttf;
    private JButton b;
    private JPanel ipjp;
    private JPanel portjp;
    private JPanel bjp;

    private ChatClient c;

    public ServerInputForm(ChatClient c) {
        setTitle("서버 정보 입력 다이얼로그");
        this.c = c;

        ipl =   new JLabel("I    P  : ");
        portl = new JLabel("Port  : ");
        iptf = new JTextField(15);
        porttf = new JTextField(15);
        b = new JButton("입 력");
        b.addActionListener(this);

        ipjp = new JPanel();
        portjp = new JPanel();
        bjp = new JPanel();

        ipjp.add(ipl);
        ipjp.add(iptf);
        portjp.add(portl);
        portjp.add(porttf);
        bjp.add(b);

        setBounds(100,100,240,130);

        getContentPane().setLayout(new GridLayout(3,1));
        getContentPane().add(ipjp);
        getContentPane().add(portjp);
        getContentPane().add(bjp);
    }

    public void actionPerformed(ActionEvent ae) {
        //입력된 서버의 정보를 다이얼로그를 호출한 클래스의 멤버
        //변수에 저장한다.
        c.setIp(iptf.getText());
        c.setPort(Integer.parseInt(porttf.getText()));
        setVisible(false);
        show(false);
    }
}
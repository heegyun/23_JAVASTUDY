package day_10;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ChatClientForm extends JFrame implements ActionListener {
    private Socket s;
    private String name;

    private BufferedWriter bw;

    private JTextArea ta;
    private JTextField tf;
    private JButton b;
    private JPanel p;

    public ChatClientForm(Socket s, String name) {
        this.s = s;
        this.name = name;
        this.setTitle(name+"님의 채팅 클라이언트");

        ta = new JTextArea();
        ta.setEditable(false);
        tf = new JTextField(25);
        b = new JButton("전송");
        b.addActionListener(this);
        p = new JPanel();
        p.add(tf);
        p.add(b);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(ta,"Center");
        getContentPane().add(p,"South");

        setBounds(100,100,400,300);

        try {
            //서버로부터 문자열을 수신하기 위한 쓰레드를 생성한다.
            ListenThread lt = new ListenThread(s, this);
            Thread t = new Thread(lt);
            t.start();

            //서버에 문자열을 송신하기 위한 출력 스트림을 생성한다.
            bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
        }catch(Exception e) {
        }
    }

    public void writeTextArea(String str) {
        ta.append(str+"\n");
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            //버튼이 클릭되면 텍스트 필드의 내용을 서버에 송신한다.
            bw.write(name+" : "+tf.getText()+"\n");
            bw.flush();
            tf.setText("");
        }catch(Exception e) {
            //서버에 문자열을 송신할 수 없으면 스트림과 소켓을 닫고
            //프로그램을 종료한다.
            try {
                bw.close();
                s.close();
            }catch(Exception e2) {}
            System.exit(0);
        }
    }
}
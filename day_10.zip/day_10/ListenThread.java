package day_10;

import java.io.*;
import java.net.*;

public class ListenThread implements Runnable {
  private Socket s;
  private ChatClientForm f;
  private BufferedReader br;
  
  public ListenThread(Socket s, ChatClientForm f) {
    this.s = s;
    this.f = f;
    
    try {
      //인자로 받은 소켓에 대한 입력 스트림을 만든다.
      br = new BufferedReader(new InputStreamReader(s.getInputStream()));
    }catch(Exception e) {
    }
  }

  //쓰레드가 시작되면 run 메서드의 내용이 실행된다.
  public void run() {
    while(true) {
      //서버로부터 받은 내용을 읽어 클라이언트의 텍스트 에어리어에 적는다.
      try {
        f.writeTextArea(br.readLine());
      }catch(Exception e) {
      }
    }
  }
}